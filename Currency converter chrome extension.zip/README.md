# Currency Converter
Simple chrome extension to converts currencies from one to another to it's equilent value.
