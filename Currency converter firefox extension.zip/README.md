# Currency Converter
Simple Friefox extension to converts currencies from one to another to it's equilent value.
